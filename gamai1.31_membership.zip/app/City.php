<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\productImages;
class City extends Model
{
    protected $table = 'cities';


}
