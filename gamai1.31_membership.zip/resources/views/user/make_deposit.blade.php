@extends('layouts.app')
@section('additional_css')
    <link href="{{ asset('css/page/profile/profile.css') }}" rel="stylesheet">


@endsection
@section('content')
    <div class="container">
        <div class="content">
            <div class="title " style="text-align:center;">
                Deposit Settings
            <p style="text-align: center; color:gray">You have {{Auth::user()->deposit}}$ in your deposit</p>
            </div>
                @if(isset($message))
                    <strong>{{$message}}</strong>
            @endif
                <form action="{{route('user.store_deposit',['id'=>Auth::user()->id])}}" class="deposit-form col-6" >
                    <div class="currency">
                        <label>Deposit Currency</label>
                        <select name="" id="">
                            <option value="0">US Dollar</option>
                        </select>
                    </div>
                    <div class="amount">
                        <label for="amount">Deposit Amount</label>
                        <input type="text" name="amount" class="pay-amount" value="">
                    </div>
                    <div class="fee">
                        <label for="fee">Processing Fee</label>
                        <label for="fee_amount" class="fee_amount" style="float:right;"></label>
                    </div>
                    <div class="total-price">
                        <label for="fee">Totoal Price </label>
                        <label for="total-fee" class="total-fee" style="float:right;" ></label>
                    </div>
                    <div class="pay-request">
                        <button class="btn-success" type="submit">Confirm and Pay</button>
                    </div>



                    <p>You agree to authorize the use of your PayPal account for this deposit and future payments.
                        </p>
                    <p>PayPal does not support Prepaid and gift cards as a funding source.</p>

                </form>




        </div>
    </div>
@endsection
@section('additional_js')
    <script>
        $(function () {
            $('.pay-amount').on('keyup',function () {
               var fee =this.value*2.5/100;
               var total = this.value + this.value*2.5/100;
               $('.fee_amount')[0].innerText = fee+'$';
               $('.total-fee')[0].innerText = total+'$';

            })
        })
    </script>

@endsection
