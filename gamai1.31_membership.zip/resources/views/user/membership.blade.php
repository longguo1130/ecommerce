@extends('layouts.app')

@section('content')
    <div class="container">
        @if(isset($message))
            <p>{{$message}}</p>
        @endif
        <table class="table table-striped">
            <tr>
                <th></th>
                @foreach($membership as $post)
                    <th>{{$post->membership_status}}
                    <p>PHP{{$post->amount}}</p></th>
                    @endforeach
            </tr>
            <tr>
                <td></td>
                @for($i=0; $i<8; $i++)
                @if($i== Auth::user()->membership)
                    <td>Current</td>
                @else
                <td><a href="{{route('user.upgrade_membership',['id'=>Auth::user()->id,'membership'=>$i])}}" class="btn btn-default">Select</a></td>
                @endif
                @endfor
            </tr>
            <tr>
                <th>Jobs @ Bidding</th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
            </tr>
            <tr>
                <td>Bid limit</td>
                @foreach($membership as $post)
                    <td>{{$post->bid_limit}}</td>
                    @endforeach

            </tr>
            <tr>
                <td>Product Fee</td>
                @foreach($membership as $post)
                    <td>{{$post->fee}}%</td>
                @endforeach
            </tr>
        </table>
    </div>

@endsection
